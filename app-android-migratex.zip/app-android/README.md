# mahasiswa-app
Sample Project Mahasiswa App

Feature on this project :
- Login connect to API
- Register connect to API
- Session Login Logout
- GET List dosen API
- GET List Matkul API
- Add data Matkul Database
- Delete Matkul by id API

I build API use Slim Framework, you can view project API in https://github.com/farizdotid/API-Mahasiswa .

App Screenshot :
<p align="center">
  <img src="https://raw.githubusercontent.com/farizdotid/mahasiswa-app/master/screenshot/device-2017-05-13-224616.png" width="250" height="400" />
   <img src="https://raw.githubusercontent.com/farizdotid/mahasiswa-app/master/screenshot/device-2017-05-13-224648.png" width="250" height="400" />
   <img src="https://raw.githubusercontent.com/farizdotid/mahasiswa-app-android/master/screenshot/device-2017-08-08-165204.png" width="250" height="400" />
    <img src="https://raw.githubusercontent.com/farizdotid/mahasiswa-app-android/master/screenshot/device-2017-08-08-165225.png" width="250" height="400" />
     <img src="https://raw.githubusercontent.com/farizdotid/mahasiswa-app-android/master/screenshot/device-2017-08-08-165307.png" width="250" height="400" />
      <img src="https://raw.githubusercontent.com/farizdotid/mahasiswa-app-android/master/screenshot/device-2017-08-08-165319.png" width="250" height="400" />
</p>
